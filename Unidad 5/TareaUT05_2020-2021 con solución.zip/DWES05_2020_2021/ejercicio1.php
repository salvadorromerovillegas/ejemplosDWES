<?php

if (class_exists('SoapClient')) {
    echo "Existe la clase SoapClient";
}
else
{
    echo "NO existe la clase SoapClient";
}
echo "<br>";

if (class_exists('SoapServer')) {
    echo "Existe la clase SoapServer";
}
else
{
    echo "NO existe la clase SoapServer";
}
echo "<br>";


