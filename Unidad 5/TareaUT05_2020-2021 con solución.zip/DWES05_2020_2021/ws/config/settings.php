<?php

/* ONLY Web service implementation settings */

define ('DB_DSN','mysql:host=localhost;dbname=incmotiv');
define ('DB_USER','root');
define ('DB_PASSWD',''); 

