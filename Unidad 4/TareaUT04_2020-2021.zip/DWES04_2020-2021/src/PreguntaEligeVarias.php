<?php

class PreguntaEligeVarias extends PreguntaEligeUna {
    
     public function tipoPregunta() {
        return "EligeVarias";
    }

}
